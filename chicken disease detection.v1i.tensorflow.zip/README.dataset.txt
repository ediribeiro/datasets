# chicken disease detection  > 2022-01-05 7:40pm
https://universe.roboflow.com/feces-dataset/chicken-disease-detection-algii

Provided by a Roboflow user
License: CC BY 4.0

